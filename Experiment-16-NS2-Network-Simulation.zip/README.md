# Experiment 16: Network Simulation Using NS-2 / NCTUns Practical

## Aim
Study network simulation and perform packet-drop, TCP/UDP traffic, congestion, and throughput experiments described in the supplied practical.

## Repository contents
- `README.md` — overview and run notes
- `Practical-Documentation.md` — procedure, examples, observation template, and conclusion
- `Original-Practical.docx` — supplied lab handout
- `evidence/` — add genuine screenshots and logs here

## Evidence
Add your own screenshots from the lab run. Do not submit sample output as if it were captured from your machine.

## GitHub upload
Create a public repository, upload these files, add actual evidence, and commit the changes.
